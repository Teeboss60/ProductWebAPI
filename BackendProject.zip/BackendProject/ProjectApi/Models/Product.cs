﻿namespace ProjectAPI.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductID { get; set; } = string.Empty;
    }
}
